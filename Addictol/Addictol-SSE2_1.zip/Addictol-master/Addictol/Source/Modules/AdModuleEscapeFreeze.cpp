#include <Modules/AdModuleEscapeFreeze.h>
#include <AdUtils.h>

#include <thread>
#include <atomic>

#define AD_NOMESSAGE_FREEZES 1

namespace Addictol
{
	static REX::TOML::Bool<> bFixesEscapeFreeze{ "Fixes"sv, "bEscapeFreeze"sv, true };
	static REX::TOML::I32<> nAdditionalSleepTimer{ "Additional"sv, "nSleepTimer"sv, 125 };
	static REX::TOML::I32<> nAdditionalMaxLockCount{ "Additional"sv, "nMaxLockCount"sv, 8 };

	REL::Relocation<int*> ConditionLockCountPointer{ REL::ID{ 998070, 2692050, 4799342 } };

	static void FreezeWatcherThread()
	{
		REX::INFO("Started FreezeWatcher Thread"sv);

		int LoopCounter = 0;
		bool Escaped = false;

		while (true)
		{
			// Are there any Locks?
			if (*ConditionLockCountPointer == 0)
			{
				if (Escaped)
					// There was and we Escaped
					REX::INFO("Successfully Escaped from Freezing!"sv);

				// Reset
				LoopCounter = 0;
				Escaped = false;

				// Sleep
				std::this_thread::sleep_for(std::chrono::milliseconds(nAdditionalSleepTimer.GetValue()));
				continue;
			}

			// Lock Detected!
#if !AD_NOMESSAGE_FREEZES
			REX::INFO("Lock Detected! Lock Count: {}, Loop Count: {}"sv, *ConditionLockCountPointer, LoopCounter++);
#else
			LoopCounter++;
#endif		// !AD_NOMESSAGE_FREEZES

			// Exceeded the Threshold
			if (LoopCounter > nAdditionalMaxLockCount.GetValue())
			{
				REX::INFO("Exceeded Threshold, Unlocking..."sv);

				*ConditionLockCountPointer = 0;
				Escaped = true;
			}

			std::this_thread::sleep_for(std::chrono::milliseconds(nAdditionalSleepTimer.GetValue()));
		}
	}

	ModuleEscapeFreeze::ModuleEscapeFreeze() :
		Module("Escape Freeze", &bFixesEscapeFreeze)
	{}

	bool ModuleEscapeFreeze::DoQuery() const noexcept
	{
		return true;
	}

	bool ModuleEscapeFreeze::DoInstall([[maybe_unused]] F4SE::MessagingInterface::Message* a_msg) noexcept
	{
		REX::INFO("Starting FreezeWatcher Thread"sv);
		std::thread(FreezeWatcherThread).detach();
		// TODO: Graceful exit

		return true;
	}

	bool ModuleEscapeFreeze::DoListener([[maybe_unused]] F4SE::MessagingInterface::Message* a_msg) noexcept
	{
		return true;
	}

	bool ModuleEscapeFreeze::DoPapyrusListener([[maybe_unused]] RE::BSScript::IVirtualMachine* a_vm) noexcept
	{
		return true;
	}
}