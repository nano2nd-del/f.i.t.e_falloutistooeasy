import { SkillName, SPECIAL } from '../engine/types';

export interface PerkDef {
  id: string;
  name: string;
  description: string;
  levelRequired: number;
  modifiers: {
    mapVisibilityBonus?: number;
    encounterRateModifier?: number; // e.g. -0.25 is 25% reduction
    skillBonuses?: Partial<Record<SkillName, number>>;
    combatAccuracyBonus?: number;
  };
}

export const PERK_REGISTRY: Record<string, PerkDef> = {
  Scout: {
    id: 'Scout',
    name: 'Scout',
    description: 'Increases local perception and map visibility radius by +1, and grants +10 to Survival.',
    levelRequired: 1,
    modifiers: {
      mapVisibilityBonus: 1,
      skillBonuses: { Survival: 10 }
    }
  },
  Ranger: {
    id: 'Ranger',
    name: 'Ranger',
    description: 'Reduces threat encounter frequencies by 25% and grants +15 to Survival.',
    levelRequired: 2,
    modifiers: {
      encounterRateModifier: -0.25,
      skillBonuses: { Survival: 15 }
    }
  },
  Explorer: {
    id: 'Explorer',
    name: 'Explorer',
    description: 'Increases map visibility radius by +2 and grants +10 to Lockpick, NatureSciences, and ComputerScience.',
    levelRequired: 3,
    modifiers: {
      mapVisibilityBonus: 2,
      skillBonuses: { Lockpick: 10, NatureSciences: 10, ComputerScience: 10 }
    }
  }
};

export interface SkillCheckResult {
  success: boolean;
  roll: number;
  successThreshold: number;
  baseValue: number;
  perkBonus: number;
  isCriticalSuccess: boolean;
  isCriticalFailure: boolean;
}

/**
 * Decoupled skill pass/fail calculations against any skill name with difficulty modifiers and perks.
 */
export function evaluateSkillCheck(
  playerSkills: Record<SkillName, number>,
  skill: SkillName,
  difficultyModifier: number, // positive subtracts from success chance (i.e. harder)
  playerPerks: string[] = []
): SkillCheckResult {
  const baseValue = playerSkills[skill] || 25;

  // Compile perk bonuses
  let perkBonus = 0;
  playerPerks.forEach((perkId) => {
    const perk = PERK_REGISTRY[perkId];
    if (perk && perk.modifiers.skillBonuses) {
      perkBonus += perk.modifiers.skillBonuses[skill] || 0;
    }
  });

  const modifiedValue = baseValue + perkBonus;
  // A standard Fallout PnP formula is: Skill% - Difficulty modifier
  const successThreshold = Math.max(5, Math.min(95, modifiedValue - difficultyModifier));

  const roll = Math.floor(Math.random() * 100) + 1;
  const success = roll <= successThreshold;

  // Let's set critical ranges
  // Critical success: rolling <= 10% of the active successThreshold (or a roll of 1)
  const isCriticalSuccess = success && (roll <= Math.max(1, Math.floor(successThreshold * 0.1)) || roll === 1);
  // Critical failure: rolling >= 95
  const isCriticalFailure = !success && (roll >= 95);

  return {
    success,
    roll,
    successThreshold,
    baseValue,
    perkBonus,
    isCriticalSuccess,
    isCriticalFailure,
  };
}

export function getMapVisibilityRadius(baseRadius: number, playerPerks: string[] = []): number {
  let bonus = 0;
  playerPerks.forEach((perkId) => {
    const perk = PERK_REGISTRY[perkId];
    if (perk && perk.modifiers.mapVisibilityBonus !== undefined) {
      bonus += perk.modifiers.mapVisibilityBonus;
    }
  });
  return baseRadius + bonus;
}

export function getEncounterFrequencyModifier(baseFreq: number, playerPerks: string[] = []): number {
  let multiplier = 1.0;
  playerPerks.forEach((perkId) => {
    const perk = PERK_REGISTRY[perkId];
    if (perk && perk.modifiers.encounterRateModifier !== undefined) {
      multiplier += perk.modifiers.encounterRateModifier;
    }
  });
  return Math.max(0.1, baseFreq * multiplier);
}

export function getVatsHitModifier(playerPerks: string[] = []): number {
  let bonus = 0;
  playerPerks.forEach((perkId) => {
    const perk = PERK_REGISTRY[perkId];
    if (perk && perk.modifiers.combatAccuracyBonus !== undefined) {
      bonus += perk.modifiers.combatAccuracyBonus;
    }
  });
  return bonus;
}

export const PERKS_LIST: PerkDef[] = Object.values(PERK_REGISTRY);
